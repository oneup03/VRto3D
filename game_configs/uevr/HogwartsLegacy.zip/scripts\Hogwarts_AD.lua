-- Original script by jbusfield, Pande4360, and DJ
-- Modified for 3D by OneUp03
local uevrUtils = require("libs/uevr_utils")


local isInCinematic = false
local isInAlohomora = false
local isInAstronomyPuzzle = false
local isInMenu = false
local isInMainMenu = false
local isInMovie = false
local isInGuidebook = false

local g_fieldGuideUIManager = nil
local currentMediaPlayers = nil
local uiManager = nil

local VR_WORLD_SCALE = "VR_WorldScale"
local menu_scale = '0.01'
local cinema_scale = '0.25'
local gameplay_scale = '1.0'

local vr = uevr.params.vr


-- Helper Function
function FindAllOf(name)
	return uevrUtils.find_all_instances(name, false)
end


-- Initialization
function UEVRReady(instance)
	print("UEVR is now ready\n")

	initLevel()	
	hookLateFunctions()
	
	if pawn.InCinematic == true then
		isInCinematic = true -- This makes the avatar in the intro screen be at the right position
	end
end

function initLevel()
	currentMediaPlayers = nil
	uiManager = nil
	
	hookLevelFunctions()
end


-- Check for cutscene
function isInCutscene()
	return isInCinematic or isInAlohomora or isInAstronomyPuzzle
end

function checkCinematic()
	if uevrUtils.validate_object(pawn) ~= nil then
		isInCinematic = pawn.InCinematic 
	end
end


-- Check for In-Game Menu
function guideBookCheck()
	if g_fieldGuideUIManager ~= nil and g_fieldGuideUIManager.FieldGuideWidget ~= nil then
		isInGuidebook = true
	else
		isInGuidebook = false
	end
end


-- Check for Shop Menus
function inMenuMode()
	if uiManager == nil then 
		uiManager = uevrUtils.find_first_of("Class /Script/Phoenix.UIManager") 
	end
	return uevrUtils.validate_object(uiManager) ~= nil and uiManager.GetIsUIShown ~= nil and uiManager:GetIsUIShown()
end

function checkIsInMenu()
	local inMenu = inMenuMode()
	if inMenu ~= isInMenu then
		inMenuChanged(inMenu)
	end
	isInMenu = inMenu
	
	checkIsInMainMenu()
end


-- Check for Main Menu
function inMainMenuChanged(newValue)
end

function inMainMenu()
	if uiManager == nil then 
		uiManager = uevrUtils.find_first_of("Class /Script/Phoenix.UIManager") 
	end
	return uevrUtils.validate_object(uiManager) ~= nil and uiManager.IsInFrontendLevel ~= nil and uiManager:IsInFrontendLevel()
end

function checkIsInMainMenu()
	local inMainMenu = inMainMenu()
	if inMainMenu ~= isInMainMenu then
		inMainMenuChanged(inMainMenu)
	end
	isInMainMenu = inMainMenu
end


-- Media Player functions
local g_mediaPlayerFadeLock = false
function mediaPlayerCheck()
	updateMediaPlayers()
	local mediaIsPlaying = false
	local spellUrlStr = ""
	local urlStr = ""
	if currentMediaPlayers == nil then
		print("No instances of 'BinkMediaPlayer' were found\n")
	else
		for Index, mp in pairs(currentMediaPlayers) do
			--print(mp)
			if uevrUtils.validate_object(mp) ~= nil then
				--print(mp.URL, mp:get_full_name(), mp:IsPlaying())
				local isPlaying = mp:IsPlaying()
				urlStr = mp.URL
				if isPlaying and isValidMedia(urlStr) then
					mediaIsPlaying = true
					--setProgressSpecificSettings(urlStr)
					print(urlStr, "\n")
				end
			end
		end
	end

	if mediaIsPlaying and not g_mediaPlayerFadeLock then
		isInMovie = true
		print("Media started\n")
		g_mediaPlayerFadeLock = true
	end
	if not mediaIsPlaying and g_mediaPlayerFadeLock then
		isInMovie = false
		print("Media stopped\n")
		g_mediaPlayerFadeLock = false
	end
end

function isValidMedia(url)
	local isValid = true
	if string.match(url, "FMV_ArrestoMomentum" ) or string.match(url, "ATL_Tapestry_Ogre_1" ) or string.match(url, "ATL_DailyProphet" ) or string.match(url, "ATL_Portrait" ) or string.match(url, "SpellPreviews") or string.match(url, "FMV_Aim_Mode_1") or string.match(url, "FMV_AM_Finisher") or string.match(url, "FMV_AutoTargeting") or string.match(url, "FMV_AMPickUps_ComboMeter")  or string.match(url, "FMV_Talent_Core_StupefyStun") then
		isValid = false
	end
	return isValid
end

function updateMediaPlayers()
	currentMediaPlayers = FindAllOf("Class /Script/BinkMediaPlayer.BinkMediaPlayer")
end


-- Checking for updates
function on_lazy_poll()
	updateMediaPlayers()
	mediaPlayerCheck()
	guideBookCheck()
	checkCinematic() 
    
	checkIsInMenu()
end

function on_level_change(level)
	print("Level changed " .. level:get_full_name())
	initLevel()
end


-- Main Function
uevr.sdk.callbacks.on_pre_engine_tick(function(engine, delta)

    if isInCutscene() or isInMovie or isInMainMenu or isInMenu then
        vr.set_mod_value(VR_WORLD_SCALE, cinema_scale)
	elseif isInGuidebook then
	    vr.set_mod_value(VR_WORLD_SCALE, menu_scale)
    else
        vr.set_mod_value(VR_WORLD_SCALE, gameplay_scale)
    end

end)


-- Detect Lockpicking
function hookLevelFunctions()
	
	hook_function("BlueprintGeneratedClass /Game/Pawn/Shared/StateTree/BTT_Biped_PuzzleMiniGame.BTT_Biped_PuzzleMiniGame_C", "ReceiveExecute", false,
		function(fn, obj, locals, result)
			print("Alohomora:ReceiveExecute\n")
			isInAlohomora = true
		end
	, nil, true)

	hook_function("BlueprintGeneratedClass /Game/Pawn/Shared/StateTree/BTT_Biped_PuzzleMiniGame.BTT_Biped_PuzzleMiniGame_C", "ExitTask", false, nil,
		function(fn, obj, locals, result)
			print("Alohomora:ExitTask\n")
			isInAlohomora = false
		end
	, true)

end


-- Handle Astronomy Minigame
function solveAstronomyMinigame()
	pawn:CHEAT_SolveMinigame()
end

local g_isLateHooked = false
function hookLateFunctions()
	if not g_isLateHooked then

		hook_function("WidgetBlueprintGeneratedClass /Game/UI/Actor/UI_BP_Astronomy_minigame.UI_BP_Astronomy_minigame_C", "ConstellationImageLoaded", true, nil,
			function(fn, obj, locals, result)
				print("Astronomy MiniGame ConstellationImageLoaded\n")
				isInAstronomyPuzzle = true
				
				--auto solve game unless we can find a solution for UEVR FOV locking
				obj:Solved()
				delay(3000, function()
					solveAstronomyMinigame()
				end)
			end
		, true)

		hook_function("WidgetBlueprintGeneratedClass /Game/UI/Actor/UI_BP_Astronomy_minigame.UI_BP_Astronomy_minigame_C", "OnOutroEnded", true, nil,
			function(fn, obj, locals, result)
				print("Astronomy MiniGame OnOutroEnded\n")
				isInAstronomyPuzzle = false
			end
		, true)

		g_isLateHooked = true
	end

end


-- Function Hooks to detect In-Game Menu
hook_function("Class /Script/Phoenix.UIManager", "FieldGuideMenuStart", true, nil,
	function(fn, obj, locals, result)
		print("UIManager:FieldGuideMenuStart\n")
		--debugModule.dump(obj)
		g_fieldGuideUIManager = obj
	end
, true)

hook_function("Class /Script/Phoenix.UIManager", "IsDirectlyEnteringSubMenu", true, nil,
	function(fn, obj, locals, result)
		print("UIManager:IsDirectlyEnteringSubMenu\n")
		g_fieldGuideUIManager = obj
	end
, true)

hook_function("Class /Script/Phoenix.UIManager", "ExitFieldGuideWithReason", true, nil,
	function(fn, obj, locals, result)
		print("UIManager:ExitFieldGuideWithReason\n")
		g_fieldGuideUIManager = nil
	end
, true)



uevrUtils.initUEVR(uevr)