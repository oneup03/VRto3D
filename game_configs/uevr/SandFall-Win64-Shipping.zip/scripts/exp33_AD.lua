------------------------------------------------------------------------------------
-- Global section
------------------------------------------------------------------------------------
local VR_WORLD_SCALE = "VR_WorldScale"
local cinema_scale = '0.25'
local gameplay_scale = '1.0'

local api = uevr.api
local vr = uevr.params.vr

-- XInput constants
local TOGGLE_BUTTON = XINPUT_GAMEPAD_BACK
local button_was_pressed = false
local toggle_cooldown = 0.0
local cooldown_threshold = 1.5  -- seconds

-- Logs to the log.txt
local function log_info(message)
	uevr.params.functions.log_info(message)
end

-- Set a CVar
function set_cvar_int(cvar, value)
    local console_manager = api:get_console_manager()
    local var = console_manager:find_variable(cvar)
    if var ~= nil then
        var:set_int(value)
    end
end

-- Acts as a rendering reset to fix 3D effects
function toggle_shadow()
	set_cvar_int("r.Shadow.Virtual.Enable", 1)
	log_info("Shadow Reset")
end

vr.set_mod_value(VR_WORLD_SCALE, gameplay_scale)

local game_engine_class = uevr.api:find_uobject("Class /Script/Engine.GameEngine")

local was_in_dialog = false
local was_in_cinematic = false

-- Engine tick callback
uevr.sdk.callbacks.on_post_engine_tick(function(engine, delta)
	toggle_cooldown = math.max(toggle_cooldown - delta, 0)

	local game_engine = UEVR_UObjectHook.get_first_object_by_class(game_engine_class)
	local player = uevr.api:get_player_controller(0)
	if not player then return end

	local isindialog = false
	local isincinematic = false

	if player.BP_DialogueSystemComponent and player.BP_DialogueSystemComponent.DialogueUI then
		isindialog = player.BP_DialogueSystemComponent.DialogueUI.IsActive == true
	end

	if player.BP_CinematicSystem then
		isincinematic = player.BP_CinematicSystem.IsPlayingCinematic == true
	end

	if isindialog and not was_in_dialog then
		vr.set_mod_value(VR_WORLD_SCALE, cinema_scale)
		toggle_shadow()
		log_info("Enter dialog")
		was_in_dialog = true
	end

	if isincinematic and not was_in_cinematic then
		vr.set_mod_value(VR_WORLD_SCALE, cinema_scale)
		toggle_shadow()
		log_info("Enter cinematic")
		was_in_cinematic = true
	end

	if not isindialog and was_in_dialog and not isincinematic then
		vr.set_mod_value(VR_WORLD_SCALE, gameplay_scale)
		log_info("Exited dialog")
		was_in_dialog = false
	end

	if not isincinematic and was_in_cinematic and not isindialog then
		vr.set_mod_value(VR_WORLD_SCALE, gameplay_scale)
		log_info("Exited cinematic")
		was_in_cinematic = false
	end
end)

-- XInput polling
uevr.sdk.callbacks.on_xinput_get_state(function(_, user_index, state)
	if user_index ~= 0 or not state or not state.Gamepad then return end
	local button_pressed = (state.Gamepad.wButtons & TOGGLE_BUTTON) ~= 0
	if button_pressed and not button_was_pressed and toggle_cooldown == 0 then
		toggle_shadow()
		log_info("Manual shadow reset triggered")
		toggle_cooldown = cooldown_threshold
	end
	button_was_pressed = button_pressed
end)
