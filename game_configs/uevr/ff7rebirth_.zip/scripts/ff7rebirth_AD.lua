------------------------------------------------------------------------------------
-- Global section
------------------------------------------------------------------------------------
local cinema_depth = '0.1'
local gameplay_depth = '0.4'

local VR_WORLD_SCALE = "VR_WorldScale"
local cinema_scale = '0.25'
local gameplay_scale = '1.0'


------------------------------------------------------------------------------------
-- Helper section
------------------------------------------------------------------------------------

local api = uevr.api
local vr = uevr.params.vr

-- Send string of floating point depth for VRto3D
local function SendDepth(depth_str)
    api:dispatch_custom_event("depth", depth_str)
end

-- Logs to the log.txt
local function log_info(message)
	uevr.params.functions.log_info(message)
end

-- returns local pawn
local function get_local_pawn()
	return api:get_local_pawn(0)
end

-- returns local player controller
local function get_player_controller()
	return api:get_player_controller(0)
end

-- Find a UObject
local function find_required_object(name)
    local obj = uevr.api:find_uobject(name)

    if not obj then
        log_info(name, "was not found")
        return nil
    end

    return obj
end

local find_static_class = function(name)
    local c = find_required_object(name)
    return c:get_class_default_object()
end

-- Check if a cutscene is playing
local function check_sequence_player(class)
    local players = class:get_objects_matching(false)
    if players == nil or #players == 0 then
        return false
    end

    for _, player in ipairs(players) do
        if player:IsPlaying() then
            return true
        end
    end

    return false
end

-- Check if game is paused
local function check_pause(class)

    if class == nil then
        return false
    end

    local game_state = class:get_first_object_matching(false)
	if game_state == nil then
        return false
    end
	
	return game_state:IsGamePause()
end

-- Check if Chadley is active
local function check_chadley(class)
	local chadley = false

    if class ~= nil then
		local obj_instances = class:get_objects_matching(false)
		if obj_instances then
			for _, media_player in ipairs(obj_instances) do
				if media_player and string.find(media_player:get_full_name(), "Chadley") then
					chadley = true
				end
			end
		end
	end
	
	return chadley
end

------------------------------------------------------------------------------------
-- Main Code
------------------------------------------------------------------------------------

local EndCinemaSequencePlayer_c = find_required_object("Class /Script/EndGame.EndCinemaSequencePlayer")
local EndDialogueSequencePlayer_c = find_required_object("Class /Script/EndGame.EndDialogueSequencePlayer")
local EndGameState = find_required_object("Class /Script/EndGame.EndGameState")
local MediaPlayer = find_required_object("Class /Script/MediaAssets.MediaPlayer")
local BattleAPI_c = find_static_class("Class /Script/EndGame.EndBattleAPI")

uevr.sdk.callbacks.on_pre_engine_tick(function(engine, delta)
    
    local pawn = get_local_pawn()

    local cutscene_playing = check_sequence_player(EndCinemaSequencePlayer_c)
    local dialogue_playing = check_sequence_player(EndDialogueSequencePlayer_c)
    local in_menu = check_pause(EndGameState)
	local is_chadley = check_chadley(MediaPlayer)
	local is_summon = BattleAPI_c:IsInSummonCutScene()
	

    if pawn == nil or not pawn:IsPlayerControlled() or in_menu or cutscene_playing or dialogue_playing or is_chadley or is_summon then
        --SendDepth(cinema_depth)
        vr.set_mod_value(VR_WORLD_SCALE, cinema_scale)
    else
        --SendDepth(gameplay_depth)
        vr.set_mod_value(VR_WORLD_SCALE, gameplay_scale)
    end

end)