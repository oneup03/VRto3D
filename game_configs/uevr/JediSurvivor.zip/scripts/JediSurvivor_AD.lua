------------------------------------------------------------------------------------
-- Global section
------------------------------------------------------------------------------------
local cinema_depth = '0.1'
local gameplay_depth = '0.4'

local VR_WORLD_SCALE = "VR_WorldScale"
local cinema_scale = '0.25'
local gameplay_scale = '1.0'


------------------------------------------------------------------------------------
-- Helper section
------------------------------------------------------------------------------------

local api = uevr.api
local vr = uevr.params.vr

-- Send string of floating point depth for VRto3D
local function SendDepth(depth_str)
    api:dispatch_custom_event("depth", depth_str)
end

-- Logs to the log.txt
local function log_info(message)
	uevr.params.functions.log_info(message)
end

-- returns local pawn
local function get_local_pawn()
	return api:get_local_pawn(0)
end

-- returns local player controller
local function get_player_controller()
	return api:get_player_controller(0)
end

-- Get first instance of a given class object
local function GetFirstInstance(class_to_search, default)
    default = default or false
	local obj_class = api:find_uobject(class_to_search)
    if obj_class == nil then 
		--log_info(class_to_search, "was not found") 
		return nil
	end

    return obj_class:get_first_object_matching(default)
end

-- Get UObject
local function find_required_object(name)
    local obj = uevr.api:find_uobject(name)

    if not obj then
        log_info(name, "was not found")
        return nil
    end

    return obj
end


-- Get class object instance matching string
local function GetInstanceMatching(obj_class, match_string)
    if obj_class == nil then 
		return nil
	end

    local obj_instances = obj_class:get_objects_matching(false)

    for i, instance in ipairs(obj_instances) do
        if string.find(instance:get_full_name(), match_string) then
			return instance
		end
	end
    
    return nil
end


-- Check if BD1 is at the workbench
local function is_at_workbench(ai_obj)
	local BD1Droid = GetInstanceMatching(ai_obj, "AB_BuddyDroid_C")

	if  BD1Droid ~= nil then
		return BD1Droid.AtWorkbench
    else
        return false
    end
end


------------------------------------------------------------------------------------
-- Main Code
------------------------------------------------------------------------------------
local AIAnim = find_required_object("Class /Script/RsGameTechRT.RsAIAnimInstance")


uevr.sdk.callbacks.on_pre_engine_tick(function(engine, delta)
    
    local pawn = get_local_pawn()

    if pawn == nil or not pawn:IsPlayerControlled() or pawn:IsInAnyCinematic() or pawn:IsInAnySequence() or is_at_workbench(AIAnim) then
        --SendDepth(cinema_depth)
        vr.set_mod_value(VR_WORLD_SCALE, cinema_scale)
    else
        --SendDepth(gameplay_depth)
        vr.set_mod_value(VR_WORLD_SCALE, gameplay_scale)
    end

end)